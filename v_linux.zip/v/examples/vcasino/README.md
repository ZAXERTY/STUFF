# VCasino
VCasino is a very simple game made to learn V.

# Compile and Run

Use this to generate a binary and then launch the game.
```bash
v VCasino.v
./VCasino
```

And this to compile and launch the game directly.
```bash
v run VCasino.v
```

Created by Thomas Senechal : https://github.com/thomas-senechal/VCasino
