# Conway's Game of Life

![](https://github.com/fuyutarow/Conways-Game-of-Life-with-Vlang/raw/master/v-gun.gif)


```
v run life.v
```

Created by fuyutarow: https://github.com/fuyutarow/Conways-Game-of-Life-with-Vlang
