
struct __mpz_struct1 {
   int x;   
};

typedef struct __mpz_struct2 {
   int x;   
} __mpz_struct_typedef;
