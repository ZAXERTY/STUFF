@include './header.md'

This is the main content:
-------------------------
@content
Name: @{p1.name}
-------------------------

@include './footer.md'
