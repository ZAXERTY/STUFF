void mut_arg(const byte *_key, size_t *val) {
	*val = 5;
}
