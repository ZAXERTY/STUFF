struct foo {
	int free;
};
