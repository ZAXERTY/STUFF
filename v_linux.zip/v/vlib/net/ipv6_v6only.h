#if !defined(IPV6_V6ONLY)

#define IPV6_V6ONLY 27

#endif
